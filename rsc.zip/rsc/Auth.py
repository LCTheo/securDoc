def verifyToken(token, user_id):
    return True
